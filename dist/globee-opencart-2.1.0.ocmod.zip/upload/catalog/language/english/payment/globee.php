<?php

$_['heading_title'] = 'GloBee';
$_['text_title'] = 'Pay with GloBee';
$_['warning_testnet'] = 'Warning: You are connected to the Globee Test System. Use Testnet funds to test the process.';
$_['button_confirm'] = 'Confirm';
