<?php

namespace GloBee\PaymentApi\Exceptions;

class PaymentRequestAlreadyExistsException extends \RuntimeException
{
}
