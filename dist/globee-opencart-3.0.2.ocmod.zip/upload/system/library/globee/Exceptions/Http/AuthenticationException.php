<?php

namespace GloBee\PaymentApi\Exceptions\Http;

class AuthenticationException extends HttpException
{
}
